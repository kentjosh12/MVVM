package com.example.kjmvvm.view_model;public class ArticleViewModel {
}
