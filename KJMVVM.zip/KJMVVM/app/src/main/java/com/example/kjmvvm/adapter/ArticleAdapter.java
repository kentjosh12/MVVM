package com.example.kjmvvm.adapter;public class ArticleAdapter {
}
