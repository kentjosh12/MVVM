package com.example.kjmvvm.repository;


import com.example.kjmvvm.retrofit.ApiRequest;

public class ArticleRepository {
//    private static final   String TAG= ArticleRepository.class.getSimpleName();
//    private  final ApiRequest apiRequest;
//
//    public
}