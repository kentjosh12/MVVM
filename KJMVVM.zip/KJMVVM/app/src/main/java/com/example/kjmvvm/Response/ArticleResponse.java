package com.example.kjmvvm.Response;

import com.example.kjmvvm.model.Article;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class ArticleResponse {
    @SerializedName("articles")
    @Expose
    private List<Article> articles;
    public List<Article> GetArticles(){return articles;}

    public void setArticles(List<Article> articles){
        this.articles = articles;
    }

    @Override
    public String toString() {
        return "DashboardNewsResponse{" +
                "article=" + articles +
                '}';
    }
}
