package com.example.kjmvvm.view;public class MainActivity {
}
